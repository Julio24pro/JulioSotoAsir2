<?php
// Verificación más profunda 
function segundaVerificacion($dni, $nombre) {
    // Verificar si el DNI tiene 8 dígitos y el nombre no esta vacío
    return (preg_match('/^\d{8}$/', $dni) && !empty($nombre));
}

// Llamar a la función con los datos del formulario
return segundaVerificacion($dni, $nombre);
?>

