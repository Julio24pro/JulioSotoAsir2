<?php
// Recibir datos del formulario
$dni = $_POST['dni'];
$nombre = $_POST['nombre'];

// Validar los datos (primera verificación)
if (empty($dni) || empty($nombre)) {
    header("Location: resultado.php?status=error");
    exit();
}

// Llamar al segundo programa para una segunda verificación
$resultado = include('segunda_verificacion.php');

if ($resultado) {
    header("Location: resultado.php?status=success&nombre=" . urlencode($nombre));
} else {
    header("Location: resultado.php?status=error");
}
?>

