<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de la Verificación</title>
</head>
<body>
    <?php
    // Obtener el estado y nombre del proceso
    $status = $_GET['status'] ?? 'error';
    $nombre = $_GET['nombre'] ?? '';

    if ($status === 'success') {
        echo "<h1>Datos verificados, hola $nombre</h1>";
    } else {
        echo "<h1>No se han podido verificar los datos</h1>";
    }
    ?>
</body>
</html>

